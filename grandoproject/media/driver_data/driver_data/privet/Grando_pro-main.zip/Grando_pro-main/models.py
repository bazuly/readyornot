from sqlalchemy import Column, Integer, String, Date
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class FTL_DB(Base):
    __tablename__ = 'FTL'

    id = Column(Integer, primary_key=True)
    name = Column(String)
    ts = Column(String)
    date_start = Column(Date)
    date_end = Column(Date)
    amount_of_pallets = Column(Integer)

