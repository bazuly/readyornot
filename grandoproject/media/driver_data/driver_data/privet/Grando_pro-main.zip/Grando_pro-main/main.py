from sqlalchemy import create_engine, func
from sqlalchemy.orm import sessionmaker

import config
import logging
import asyncio
import asyncpg
from aiogram import Bot, Dispatcher, types
from handlers import start_command, button_pressed_handler


logging.basicConfig(level=logging.INFO)
# engine = create_engine(
#     f'postgresql+asyncpg://{config.DB_USER}:{config.DB_PASS}@{config.DB_HOST}:{config.DB_PORT}/{config.DB_NAME}'
# )
# Session = sessionmaker(bind=engine)


async def setup_db():
    db = await asyncpg.connect(
        host=config.DB_HOST,
        port=config.DB_PORT,
        database=config.DB_NAME,
        user=config.DB_USER,
        password=config.DB_PASS
    )
    return db


class Grando_bot:
    def __init__(self):
        self.bot = Bot(token=config.BOT_TOKEN)
        self.dp = Dispatcher(self.bot)
        self.value = ''
        self.limit = 5

        self.setup_handlers()

    def setup_handlers(self):
        self.dp.register_message_handler(self.set_limit_handler, commands=['set_limit'])
        self.dp.register_message_handler(start_command, commands=['start'])
        self.dp.register_callback_query_handler(button_pressed_handler)
        self.dp.register_message_handler(self.handle_message, commands=['info'])

    async def start(self):
        await self.dp.start_polling()

    async def handle_message(self, message: types.Message):
        try:
            self.value = message.text

            info = self.value.split()
            if len(info) > 1 and info[0] == '/info':
                first_value = info[1]
            else:
                await message.answer('Error: missing value')
                return

            parts = self.value.split(' ', 2)
            if len(parts) >= 3:
                second_value = parts[2].split()[0]
            else:
                await message.answer('Error: missing value')
                return

            data = await self.get_data_from_db(first_value, second_value)
            await self.process_data(message, data)
        except Exception as e:
            await message.answer(e)

    async def set_limit_handler(self, message: types.Message):
        try:
            arg = message.text.split()[1].lower()
            if arg == 'default':
                self.limit = 5
                await message.answer('Limit set to default: 5')
            else:
                self.limit = int(arg)
                if self.limit > 30:
                    raise ValueError('Invalid limit')
                else:
                    await message.answer(f'Limit set to: {self.limit}')
        except (IndexError, ValueError):
            await message.answer('Limit cannot be > 30')

    async def get_data_from_db(self, first_value, second_value):
        db = await setup_db()
        str_limit = str(self.limit)
        if first_value == 'name':
            second_value = second_value.title()
            result = await db.fetch(
                f"SELECT * from FTL where {first_value} = '{second_value}' ORDER BY {first_value} DESC LIMIT {str_limit}")

        elif first_value == 'ts':
            result = await db.fetch(
                f"SELECT * from FTL where {first_value} = '{second_value}' ORDER BY {first_value} DESC LIMIT {str_limit}"
            )

        elif first_value[4] == '-' and first_value[7] == '-':  # ebaniy costil', peredelat'
            result = await db.fetch(
                f"select * from FTL where date_start >= '{first_value}' AND date_end <= '{second_value}' ORDER BY \
                {first_value} DESC LIMIT {str_limit}"
            )
        else:
            result = await db.fetch(
                f"SELECT * from FTL where {first_value} = '{second_value}' ORDER BY {first_value} "
                f"DESC LIMIT {str_limit}")
        await db.close()
        return result

    async def process_data(self, message, data):
        result = ""

        for item in data:
            result += '\n'
            result += 'Name: ' + str(item['name'])
            result += '\n'
            result += 'Car: ' + str(item['ts'])
            result += '\n'
            result += 'Start: ' + str(item['date_start'])
            result += '\n'
            result += 'End: ' + str(item['date_end'])
            result += '\n'
            result += 'amount_of_pallets: ' + str(item['amount_of_pallets'])
            result += '\n'
        print(result)
        await message.answer(result)


if __name__ == "__main__":
    bot = Grando_bot()
    asyncio.run(bot.start())
