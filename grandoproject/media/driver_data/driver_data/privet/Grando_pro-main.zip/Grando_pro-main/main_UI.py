import asyncio
import asyncpg
import customtkinter as ctk
import config
from datetime import datetime
from PIL import ImageTk, Image


# db connection
async def insert_data_into_db(car_number, driver_name, date_start, date_end):
    try:
        db_connection = await asyncpg.connect(
            host=config.DB_HOST,
            port=config.DB_PORT,
            database=config.DB_NAME,
            user=config.DB_USER,
            password=config.DB_PASS

        )
        # db creation if needed
        await db_connection.execute("""
                CREATE TABLE IF NOT EXISTS Grando_FTL (
                    id SERIAL PRIMARY KEY,
                    car_number VARCHAR(255) NOT NULL,
                    driver_name VARCHAR(255) NOT NULL,
                    date_start DATE NOT NULL,
                    date_end DATE NOT NULL

                )
            """)

        await db_connection.execute(
            'INSERT INTO Grando_FTL (car_number, driver_name, date_start, date_end) VALUES ($1, $2, $3, $4)',
            car_number, driver_name, date_start, date_end)
        await db_connection.close()
        print('Data inserted')
    except asyncpg.PostgresError as e:
        print('Error:', e)


# UI core

window = ctk.CTk()
window.title('GrandoPro')
window.geometry('900x600')
ctk.set_appearance_mode("Light")
ctk.set_default_color_theme("blue")

#  load image
image = Image.open('grando.jpg')
image = image.resize((900, 600))
photo = ImageTk.PhotoImage(image)

# set image as background label
background_label = ctk.CTkLabel(window, image=photo)
background_label.place(x=0, y=0, relwidth=1, relheight=1)

# inserting data
car_number_label = ctk.CTkLabel(window, text='Номер машины', font=('Arial', 18))
car_number_label.place(x=10, y=120)

car_number_entry = ctk.CTkEntry(window, width=250)
car_number_entry.place(x=150, y=120)

driver_name_label = ctk.CTkLabel(window, text='Водитель', font=('Arial', 18))
driver_name_label.place(x=10, y=170)

driver_name_entry = ctk.CTkEntry(window, width=250)
driver_name_entry.place(x=150, y=170)

date_start_label = ctk.CTkLabel(window, text='Дата выезда', font=('Arial', 18))
date_start_label.place(x=10, y=220)

date_start_entry = ctk.CTkEntry(window, width=250)
date_start_entry.place(x=150, y=220)

date_end_label = ctk.CTkLabel(window, text='Дата прибытия', font=('Arial', 18))
date_end_label.place(x=10, y=270)

date_end_entry = ctk.CTkEntry(window, width=250)
date_end_entry.place(x=150, y=270)


async def add_data_in_db():
    car_number_str = str(car_number_entry.get())
    driver_name = str(driver_name_entry.get())
    date_start_str = str(date_start_entry.get())
    date_end_str = str(date_end_entry.get())

    # convert datetime
    date_start = datetime.strptime(date_start_str, '%d.%m.%Y').date()
    date_end = datetime.strptime(date_end_str, '%d.%m.%Y').date()

    # remove space bars in car number
    letter_counter = 0
    for i in car_number_str:
        if i.isalpha() or i.isnumeric():
            letter_counter += 1

    if letter_counter <= 9:
        car_number_str = car_number_str.replace(' ', '').upper()
    else:
        car_number_str.strip().upper()

    car_number = car_number_str

    await insert_data_into_db(car_number, driver_name, date_start, date_end)


def add_button_click():
    asyncio.run(add_data_in_db())


add_button = ctk.CTkButton(window, text='Добавить данные', command=add_button_click)
add_button.place(x=140, y=320)

car_number_entry.bind('<Return>', lambda event: add_button_click())
driver_name_entry.bind('<Return>', lambda event: add_button_click())
date_start_entry.bind('<Return>', lambda event: add_button_click())
date_end_entry.bind('<Return>', lambda event: add_button_click())

window.mainloop()
