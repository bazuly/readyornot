x = 'asdasd112sad'
print(x.upper())