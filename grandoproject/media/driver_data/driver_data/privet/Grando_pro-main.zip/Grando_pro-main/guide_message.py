guide = 'To select info that you need - type command /info \n' \
        'example: /info Name Bufetov \n' \
        'example: /info date_start 2023-05-05 \n' \
        '\n' \
        'if you want to set limit of messages \n' \
        'use command /set_limit + number \n' \
        'example: /set_limit 10 \n' \
        '\n' \
        'Also you can select data from start date to end date \n' \
        'example: /info 2023-01-01 2023-01-03'

msg = 'If you want to get info, press the button' 